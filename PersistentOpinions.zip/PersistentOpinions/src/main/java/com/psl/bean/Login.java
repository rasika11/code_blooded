package com.psl.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Login {

	@Id
	@GeneratedValue
	private int Id;
	private String domainName;
	
	public Login( String domainName, String password, int employeeId) {
		super();
		this.domainName = domainName;
		this.password = password;
		this.employeeId = employeeId;
	}
	private String password;
	private int employeeId;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

}
