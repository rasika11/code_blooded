package com.psl.testing;

import java.sql.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.psl.bean.Department;
import com.psl.bean.Login;
import com.psl.bean.PollsCreator;
import com.psl.dao.DepartmentDao;
import com.psl.dao.LoginDao;
import com.psl.dao.PollsCreatorDao;

public class HibernateTest {
 
	@Test
	public void testAdd(){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("cfg.xml");
		
		DepartmentDao d = (DepartmentDao) context.getBean("DepartmentDao");
		//DepartmentDao dd = new DepartmentDao();
		d.add(new Department(101, "Admin", 020123));
	}
	 
	@Test
	public void testAddLogin(){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("cfg.xml");
		
		LoginDao logDao= (LoginDao) context.getBean("LoginDao");
		//DepartmentDao dd = new DepartmentDao();
		logDao.add(new Login("ashish_samarth","password12345", 020001));
	}
	 
	@Test
	public void testAddPollscreator(){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("cfg.xml");
		
		PollsCreatorDao pollsCreatorDao= (PollsCreatorDao) context.getBean("PollsCreatorDao");
		//DepartmentDao dd = new DepartmentDao();
		pollsCreatorDao.add(new PollsCreator("How was Pulse2016 ?",020341,2.4, "Great", 101, "general",new Date(1, 2, 2016)));
	
	 
 
}
}