package com.psl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.PollsCreator;


@Component("PollsCreatorDao")
public class PollsCreatorDao {
	//using spring to inject object of sessionfactory..
	@Autowired
	private SessionFactory sessionFactory;
	
	//@Transactional // declarative transaction mngment
	public void add(PollsCreator pollsCreated){
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(pollsCreated);
		session.getTransaction().commit();
			
	}
	

}
