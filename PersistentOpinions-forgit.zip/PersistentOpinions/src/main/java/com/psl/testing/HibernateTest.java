package com.psl.testing;

import java.sql.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.psl.bean.Department;
import com.psl.bean.Employee;
import com.psl.bean.Login;
import com.psl.bean.PollsCreator;
import com.psl.bean.PollsRated;
import com.psl.bean.Project;
import com.psl.bean.Shuttle;
import com.psl.bean.Training;
import com.psl.bean.TrainingQuestionSet;
import com.psl.dao.DepartmentDao;
import com.psl.dao.EmployeeDao;
import com.psl.dao.LoginDao;
import com.psl.dao.PollsCreatorDao;
import com.psl.dao.PollsRatedDao;
import com.psl.dao.ProjectDao;
import com.psl.dao.ShuttleDao;
import com.psl.dao.TrainingDao;
import com.psl.dao.TrainingQuestionSetDao;

public class HibernateTest {

	@Test
	public void testAdd() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		DepartmentDao d = (DepartmentDao) context.getBean("DepartmentDao");
		// DepartmentDao dd = new DepartmentDao();
		d.add(new Department(101, "Admin", 020123));
	}

	@Test
	public void testAddLogin() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		LoginDao logDao = (LoginDao) context.getBean("LoginDao");
		// DepartmentDao dd = new DepartmentDao();
		logDao.add(new Login("ashish_samarth", "password12345", 020001));
	}

	@Test
	public void testAddPollscreator() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		PollsCreatorDao pollsCreatorDao = (PollsCreatorDao) context.getBean("PollsCreatorDao");
		// DepartmentDao dd = new DepartmentDao();
		pollsCreatorDao.add(new PollsCreator("How was Pulse2016 ?", 020341,2.4, "Great", 101, "general",null));

	}

	@Test
	public void testAddPollRated() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		PollsRatedDao pollsRatedDao = (PollsRatedDao) context
				.getBean("PollsRatedDao");
		// DepartmentDao dd = new DepartmentDao();
		pollsRatedDao.add(new PollsRated(2, 020341, "Great", 3, null));

	}

	@Test
	public void testAddProjectDao() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		ProjectDao projectDao = (ProjectDao) context.getBean("ProjectDao");
		// DepartmentDao dd = new DepartmentDao();
		projectDao.add(new Project(123, "yasur", "IBM"));

	}
	
	@Test
	public void testAddShuttleDao() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		ShuttleDao shuttleDao = (ShuttleDao) context
				.getBean("ShuttleDao");
		// DepartmentDao dd = new DepartmentDao();
		shuttleDao.add(new Shuttle(102, 4, "SB Road"));

	}

	@Test
	public void testAddTrainingDao() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		TrainingDao trainingDao = (TrainingDao) context
				.getBean("TrainingDao");
		// DepartmentDao dd = new DepartmentDao();
		trainingDao.add(new Training(111,"Hibernate","Java_Course",null,null));

	}
	
	@Test
	public void testAddTrainingQuestionsetDao() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		TrainingQuestionSetDao trainingQuestionSetDao = (TrainingQuestionSetDao) context
				.getBean("TrainingQuestionsetDao");
		// DepartmentDao dd = new DepartmentDao();
		trainingQuestionSetDao.add(new TrainingQuestionSet(1,"How was training ?"));

	}
	
	@Test
	public void testAddEmployeeDao() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"cfg.xml");

		EmployeeDao employeeDao = (EmployeeDao) context
				.getBean("EmployeeDao");
		// DepartmentDao dd = new DepartmentDao();
		employeeDao.add(new Employee(020465,"Pooja Sathe","Software Engineer",4,12,3,"Blue Ridge",101,111));

	}
}