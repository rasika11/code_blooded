package com.psl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.Employee;
import com.psl.utility.HibernateUtility;
@Component("EmployeeDao")
public class EmployeeDao {

			//using spring to inject object of sessionfactory..
	/*	@Autowired
		private SessionFactory sessionFactory;
	*/	
		//@Transactional // declarative transaction mngment
		public void add(Employee employee){
			
			System.out.println("Helllo");
	/*		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
			Session session=sessionFactory.openSession();
			
		Session session = sessionFactory.openSession();
	*/		
			SessionFactory sf = HibernateUtility.getSesionFactory();	
			Session session = sf.openSession();
			
			//session.beginTransaction();
			
			//Session session = new Configuration().configure().buildSessionFactory().openSession();
			//Transaction t = session.beginTransaction();
			
			session.beginTransaction();
			session.save(employee);
			session.getTransaction().commit();
			
		/*	t.begin();
			session.save(employee);
			t.commit();*/
			session.close();
		}
		
	}



