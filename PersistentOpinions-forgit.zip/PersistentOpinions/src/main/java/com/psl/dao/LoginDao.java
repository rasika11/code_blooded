package com.psl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.Login;
;

	
	
//@EnableTransactionManagement
	@Component("LoginDao")
	public class LoginDao {

		//using spring to inject object of sessionfactory..
		@Autowired
		private SessionFactory sessionFactory;
		
		//@Transactional // declarative transaction mngment
		public void add(Login login){
			
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(login);
			session.getTransaction().commit();
				
		}
		
	}


	
		



