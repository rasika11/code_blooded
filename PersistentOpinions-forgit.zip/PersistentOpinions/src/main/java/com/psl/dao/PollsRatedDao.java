package com.psl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.DepartmentPolls;
import com.psl.bean.PollsRated;


@Component("PollsRatedDao")
public class PollsRatedDao {
	//using spring to inject object of sessionfactory..
		@Autowired
		private SessionFactory sessionFactory;
		
		//@Transactional // declarative transaction mngment
		public void add(PollsRated pollsRated){
			
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(pollsRated);
			session.getTransaction().commit();
				
		}
		
}
