package com.psl.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.Shuttle;

@Component("ShuttleDao")
public class ShuttleDao {
	
		//using spring to inject object of sessionfactory..
			@Autowired
			private SessionFactory sessionFactory;
			
			//@Transactional // declarative transaction mngment
			public void add(Shuttle shuttle){
				
				Session session = sessionFactory.openSession();
				session.beginTransaction();
				session.save(shuttle);
				session.getTransaction().commit();
					
			}
}
