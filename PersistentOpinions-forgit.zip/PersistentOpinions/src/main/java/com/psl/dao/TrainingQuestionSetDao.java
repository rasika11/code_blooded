package com.psl.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.psl.bean.TrainingQuestionSet;

@Component("TrainingQuestionsetDao")
public class TrainingQuestionSetDao {



	
		//using spring to inject object of sessionfactory..
		@Autowired
		private SessionFactory sessionFactory;
		
		//@Transactional // declarative transaction mngment
		public void add(TrainingQuestionSet trainingQuestionSet){
			
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(trainingQuestionSet);
			session.getTransaction().commit();
				
		}
	

	
}
