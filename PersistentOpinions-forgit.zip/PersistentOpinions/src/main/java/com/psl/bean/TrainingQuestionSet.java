package com.psl.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TrainingQuestionSet {
	@Id
	public int getQuestionId() {
		return questionId;
	}
	public TrainingQuestionSet(int questionId, String question) {
		super();
		this.questionId = questionId;
		this.question = question;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	private int questionId;
	private String question;
}
