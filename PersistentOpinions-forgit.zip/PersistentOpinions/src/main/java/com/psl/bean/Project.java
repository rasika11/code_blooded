package com.psl.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Project {
	@Id
	private int projectId;
	public Project(int projectId, String project_Name, String businessUnit) {
		super();
		this.projectId = projectId;
		this.project_Name = project_Name;
		this.businessUnit = businessUnit;
	}
	private String project_Name;
	private String businessUnit;
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProject_Name() {
		return project_Name;
	}
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
}
