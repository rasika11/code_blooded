package com.psl.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class PollsRated {
	@Id
	private int pollId;
	private int employeeId;
	private String comment;
	private int rate;
	private Date date;
	public int getPollId() {
		return pollId;
	}
	public PollsRated(int pollId, int employeeId, String comment, int rate,
			Date date) {
		super();
		this.pollId = pollId;
		this.employeeId = employeeId;
		this.comment = comment;
		this.rate = rate;
		this.date = date;
	}
	public void setPollId(int pollId) {
		this.pollId = pollId;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}
