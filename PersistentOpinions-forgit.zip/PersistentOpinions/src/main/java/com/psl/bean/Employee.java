package com.psl.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	public Employee(int employeeId, String employeeName, String designation,
			int shuttleId, int managerId, int trainingId, String location,
			int projectId, int departmentId) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.designation = designation;
		this.shuttleId = shuttleId;
		this.managerId = managerId;
		this.trainingId = trainingId;
		this.location = location;
		this.projectId = projectId;
		this.departmentId = departmentId;
	}
	
	@Id
	private int employeeId;
	private String employeeName;
	private String designation;
	private int shuttleId;
	private int managerId;
	private int trainingId;
	private String location;
	private int projectId;
	private int departmentId;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getShuttleId() {
		return shuttleId;
	}
	public void setShuttleId(int shuttleId) {
		this.shuttleId = shuttleId;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	
}
